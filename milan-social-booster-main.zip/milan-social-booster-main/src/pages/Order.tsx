import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useCurrency } from '@/contexts/CurrencyContext';
import { supabase } from '@/integrations/supabase/client';
import { Navbar } from '@/components/Navbar';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { z } from 'zod';

const orderSchema = z.object({
  link: z.string().url({ message: 'Please enter a valid URL' }).max(500),
  quantity: z.number().min(1, { message: 'Quantity must be at least 1' }),
});

const Order = () => {
  const { user, loading: authLoading } = useAuth();
  const { formatAmount } = useCurrency();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [services, setServices] = useState<any[]>([]);
  const [selectedCategory, setSelectedCategory] = useState('');
  const [selectedService, setSelectedService] = useState('');
  const [link, setLink] = useState('');
  const [quantity, setQuantity] = useState('');
  const [totalPrice, setTotalPrice] = useState(0);
  const [balance, setBalance] = useState(0);

  const categories = ['YouTube', 'Facebook', 'TikTok', 'Instagram'];

  useEffect(() => {
    if (!authLoading && !user) {
      navigate('/auth');
    }
  }, [user, authLoading, navigate]);

  useEffect(() => {
    if (user) {
      fetchServices();
      fetchBalance();
    }
  }, [user]);

  useEffect(() => {
    if (selectedService && quantity) {
      calculatePrice();
    } else {
      setTotalPrice(0);
    }
  }, [selectedService, quantity]);

  const fetchServices = async () => {
    const { data } = await supabase
      .from('services')
      .select('*')
      .eq('is_active', true)
      .order('category');
    
    if (data) setServices(data);
  };

  const fetchBalance = async () => {
    if (!user) return;
    const { data } = await supabase
      .from('profiles')
      .select('balance')
      .eq('id', user.id)
      .single();
    
    if (data) setBalance(data.balance);
  };

  const calculatePrice = () => {
    const service = services.find(s => s.id === selectedService);
    if (service && quantity) {
      const qty = parseInt(quantity);
      if (qty >= service.min_quantity && qty <= service.max_quantity) {
        setTotalPrice(service.price_per_unit * qty);
      }
    }
  };

  const filteredServices = services.filter(s => s.category === selectedCategory);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedService || !link || !quantity) {
      toast.error('Please fill in all fields');
      return;
    }

    try {
      const validated = orderSchema.parse({
        link,
        quantity: parseInt(quantity),
      });

      if (totalPrice > balance) {
        toast.error('Insufficient balance');
        return;
      }

      setLoading(true);

      // Create order
      const { error: orderError } = await supabase
        .from('orders')
        .insert({
          user_id: user!.id,
          service_id: selectedService,
          link: validated.link,
          quantity: validated.quantity,
          total_price: totalPrice,
          status: 'pending',
        });

      if (orderError) throw orderError;

      // Update balance
      const { error: balanceError } = await supabase
        .from('profiles')
        .update({ balance: balance - totalPrice })
        .eq('id', user!.id);

      if (balanceError) throw balanceError;

      toast.success('Order placed successfully!');
      navigate('/orders');
    } catch (error) {
      if (error instanceof z.ZodError) {
        toast.error(error.errors[0].message);
      } else {
        toast.error('Failed to place order');
        console.error(error);
      }
    } finally {
      setLoading(false);
    }
  };

  if (authLoading) {
    return (
      <div className="min-h-screen bg-gradient-subtle">
        <Navbar />
        <div className="container mx-auto px-4 py-8">Loading...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-subtle">
      <Navbar />
      
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-2xl mx-auto">
          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="text-2xl">Place New Order</CardTitle>
              <CardDescription>Select a service and boost your social media</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="category">Category</Label>
                  <Select value={selectedCategory} onValueChange={(val) => {
                    setSelectedCategory(val);
                    setSelectedService('');
                  }}>
                    <SelectTrigger className="bg-card">
                      <SelectValue placeholder="Select platform" />
                    </SelectTrigger>
                    <SelectContent className="bg-card">
                      {categories.map(cat => (
                        <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {selectedCategory && (
                  <div className="space-y-2">
                    <Label htmlFor="service">Service</Label>
                    <Select value={selectedService} onValueChange={setSelectedService}>
                      <SelectTrigger className="bg-card">
                        <SelectValue placeholder="Select service" />
                      </SelectTrigger>
                      <SelectContent className="bg-card">
                        {filteredServices.map(service => (
                          <SelectItem key={service.id} value={service.id}>
                            {service.service_name} - {formatAmount(service.price_per_unit)}/unit
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}

                {selectedService && (
                  <>
                    <div className="space-y-2">
                      <Label htmlFor="link">Link</Label>
                      <Input
                        id="link"
                        placeholder="https://..."
                        value={link}
                        onChange={(e) => setLink(e.target.value)}
                        required
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="quantity">Quantity</Label>
                      <Input
                        id="quantity"
                        type="number"
                        placeholder="Enter quantity"
                        value={quantity}
                        onChange={(e) => setQuantity(e.target.value)}
                        min={services.find(s => s.id === selectedService)?.min_quantity}
                        max={services.find(s => s.id === selectedService)?.max_quantity}
                        required
                      />
                      {selectedService && (
                        <p className="text-sm text-muted-foreground">
                          Min: {services.find(s => s.id === selectedService)?.min_quantity}, 
                          Max: {services.find(s => s.id === selectedService)?.max_quantity}
                        </p>
                      )}
                    </div>

                    {totalPrice > 0 && (
                      <Card className="bg-gradient-primary text-primary-foreground">
                        <CardContent className="pt-6">
                          <div className="flex justify-between items-center">
                            <span className="text-lg">Total Price:</span>
                            <span className="text-2xl font-bold">{formatAmount(totalPrice)}</span>
                          </div>
                          <div className="mt-2 text-sm opacity-90">
                            Current Balance: {formatAmount(balance)}
                          </div>
                        </CardContent>
                      </Card>
                    )}

                    <Button 
                      type="submit" 
                      className="w-full bg-gradient-primary"
                      size="lg"
                      disabled={loading || totalPrice > balance}
                    >
                      {loading ? 'Placing Order...' : 'Place Order'}
                    </Button>
                  </>
                )}
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Order;