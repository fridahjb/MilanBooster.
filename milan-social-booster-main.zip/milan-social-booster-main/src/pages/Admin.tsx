import { useEffect, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useCurrency } from '@/contexts/CurrencyContext';
import { supabase } from '@/integrations/supabase/client';
import { Navbar } from '@/components/Navbar';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';
import { format } from 'date-fns';
import { Trash2, Edit, Plus } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';

const Admin = () => {
  const { user, userRole, loading: authLoading } = useAuth();
  const { formatAmount } = useCurrency();
  const navigate = useNavigate();
  const [orders, setOrders] = useState<any[]>([]);
  const [users, setUsers] = useState<any[]>([]);
  const [services, setServices] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [editingService, setEditingService] = useState<any>(null);
  const [showServiceDialog, setShowServiceDialog] = useState(false);
  const [showNotificationDialog, setShowNotificationDialog] = useState(false);

  useEffect(() => {
    if (!authLoading && (!user || userRole !== 'admin')) {
      navigate('/dashboard');
      toast.error('Access denied');
    }
  }, [user, userRole, authLoading, navigate]);

  useEffect(() => {
    if (userRole === 'admin') {
      fetchOrders();
      fetchUsers();
      fetchServices();
    }
  }, [userRole]);

  const fetchOrders = async () => {
    const { data } = await supabase
      .from('orders')
      .select(`
        *,
        services (category, service_name),
        profiles (full_name, email)
      `)
      .order('created_at', { ascending: false });
    
    if (data) setOrders(data);
  };

  const fetchUsers = async () => {
    const { data } = await supabase
      .from('profiles')
      .select('*')
      .order('created_at', { ascending: false });
    
    if (data) setUsers(data);
  };

  const fetchServices = async () => {
    const { data } = await supabase
      .from('services')
      .select('*')
      .order('category');
    
    if (data) setServices(data);
  };

  const updateOrderStatus = async (orderId: string, newStatus: 'pending' | 'processing' | 'completed' | 'cancelled') => {
    const { error } = await supabase
      .from('orders')
      .update({ status: newStatus })
      .eq('id', orderId);

    if (error) {
      toast.error('Failed to update order status');
      return;
    }

    toast.success('Order status updated');
    fetchOrders();
  };

  const addFunds = async (userId: string, amount: number) => {
    const user = users.find(u => u.id === userId);
    if (!user) return;

    const { error } = await supabase
      .from('profiles')
      .update({ balance: user.balance + amount })
      .eq('id', userId);

    if (error) {
      toast.error('Failed to add funds');
      return;
    }

    toast.success('Funds added successfully');
    fetchUsers();
  };

  const deleteUser = async (userId: string) => {
    const { error } = await supabase.auth.admin.deleteUser(userId);

    if (error) {
      toast.error('Failed to delete user');
      return;
    }

    toast.success('User deleted successfully');
    fetchUsers();
  };

  const saveService = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setLoading(true);

    const formData = new FormData(e.currentTarget);
    const serviceData = {
      category: formData.get('category') as string,
      service_name: formData.get('service_name') as string,
      price_per_unit: parseFloat(formData.get('price_per_unit') as string),
      min_quantity: parseInt(formData.get('min_quantity') as string),
      max_quantity: parseInt(formData.get('max_quantity') as string),
      is_active: true,
    };

    let error;
    if (editingService) {
      ({ error } = await supabase
        .from('services')
        .update(serviceData)
        .eq('id', editingService.id));
    } else {
      ({ error } = await supabase
        .from('services')
        .insert(serviceData));
    }

    if (error) {
      toast.error('Failed to save service');
      console.error(error);
    } else {
      toast.success(`Service ${editingService ? 'updated' : 'created'} successfully`);
      setShowServiceDialog(false);
      setEditingService(null);
      fetchServices();
    }

    setLoading(false);
  };

  const deleteService = async (serviceId: string) => {
    const { error } = await supabase
      .from('services')
      .delete()
      .eq('id', serviceId);

    if (error) {
      toast.error('Failed to delete service');
      return;
    }

    toast.success('Service deleted successfully');
    fetchServices();
  };

  const sendNotification = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setLoading(true);

    const formData = new FormData(e.currentTarget);
    const title = formData.get('title') as string;
    const message = formData.get('message') as string;
    const recipientId = formData.get('recipient') as string;

    const { error } = await supabase
      .from('notifications')
      .insert({
        user_id: recipientId === 'all' ? null : recipientId,
        title,
        message,
      });

    if (error) {
      toast.error('Failed to send notification');
      console.error(error);
    } else {
      toast.success('Notification sent successfully');
      setShowNotificationDialog(false);
    }

    setLoading(false);
  };

  if (authLoading) {
    return (
      <div className="min-h-screen bg-gradient-subtle">
        <Navbar />
        <div className="container mx-auto px-4 py-8">Loading...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-subtle">
      <Navbar />
      
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Admin Panel</h1>
          <p className="text-muted-foreground">Manage users, orders, and services</p>
        </div>

        <Tabs defaultValue="orders" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="orders">Orders</TabsTrigger>
            <TabsTrigger value="users">Users</TabsTrigger>
            <TabsTrigger value="services">Services</TabsTrigger>
            <TabsTrigger value="notifications">Notifications</TabsTrigger>
          </TabsList>

          <TabsContent value="orders" className="space-y-4">
            {orders.map((order) => (
              <Card key={order.id} className="shadow-md">
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-lg">
                        {order.services?.category} - {order.services?.service_name}
                      </CardTitle>
                      <CardDescription>
                        {order.profiles?.full_name} ({order.profiles?.email})
                      </CardDescription>
                    </div>
                    <Select
                      value={order.status}
                      onValueChange={(val) => updateOrderStatus(order.id, val as 'pending' | 'processing' | 'completed' | 'cancelled')}
                    >
                      <SelectTrigger className="w-40 bg-card">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-card">
                        <SelectItem value="pending">Pending</SelectItem>
                        <SelectItem value="processing">Processing</SelectItem>
                        <SelectItem value="completed">Completed</SelectItem>
                        <SelectItem value="cancelled">Cancelled</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-3 gap-4 text-sm">
                    <div>
                      <p className="text-muted-foreground">Link</p>
                      <p className="break-all">{order.link}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Quantity</p>
                      <p className="font-semibold">{order.quantity.toLocaleString()}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Price</p>
                      <p className="font-semibold">{formatAmount(order.total_price)}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </TabsContent>

          <TabsContent value="users" className="space-y-4">
            {users.map((user) => (
              <Card key={user.id} className="shadow-md">
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-lg">{user.full_name}</CardTitle>
                      <CardDescription>{user.email}</CardDescription>
                    </div>
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button variant="destructive" size="sm">
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent className="bg-card">
                        <AlertDialogHeader>
                          <AlertDialogTitle>Delete User</AlertDialogTitle>
                          <AlertDialogDescription>
                            Are you sure you want to delete this user? This action cannot be undone.
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>Cancel</AlertDialogCancel>
                          <AlertDialogAction onClick={() => deleteUser(user.id)}>
                            Delete
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-4">
                    <div className="flex-1">
                      <p className="text-sm text-muted-foreground">Balance</p>
                      <p className="text-2xl font-bold">{formatAmount(user.balance)}</p>
                    </div>
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button variant="outline">Add Funds</Button>
                      </DialogTrigger>
                      <DialogContent className="bg-card">
                        <DialogHeader>
                          <DialogTitle>Add Funds to {user.full_name}</DialogTitle>
                        </DialogHeader>
                        <form onSubmit={(e) => {
                          e.preventDefault();
                          const amount = parseFloat((e.target as any).amount.value);
                          addFunds(user.id, amount);
                        }}>
                          <div className="space-y-4">
                            <div>
                              <Label htmlFor="amount">Amount (KSH)</Label>
                              <Input
                                id="amount"
                                name="amount"
                                type="number"
                                step="0.01"
                                min="0"
                                required
                              />
                            </div>
                            <DialogFooter>
                              <Button type="submit" className="bg-gradient-primary">
                                Add Funds
                              </Button>
                            </DialogFooter>
                          </div>
                        </form>
                      </DialogContent>
                    </Dialog>
                  </div>
                </CardContent>
              </Card>
            ))}
          </TabsContent>

          <TabsContent value="services" className="space-y-4">
            <Dialog open={showServiceDialog} onOpenChange={setShowServiceDialog}>
              <DialogTrigger asChild>
                <Button className="bg-gradient-primary" onClick={() => {
                  setEditingService(null);
                  setShowServiceDialog(true);
                }}>
                  <Plus className="mr-2 h-4 w-4" />
                  Add Service
                </Button>
              </DialogTrigger>
              <DialogContent className="bg-card">
                <DialogHeader>
                  <DialogTitle>{editingService ? 'Edit' : 'Add'} Service</DialogTitle>
                </DialogHeader>
                <form onSubmit={saveService}>
                  <div className="space-y-4">
                    <div>
                      <Label>Category</Label>
                      <Select name="category" defaultValue={editingService?.category} required>
                        <SelectTrigger className="bg-card">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent className="bg-card">
                          <SelectItem value="YouTube">YouTube</SelectItem>
                          <SelectItem value="Facebook">Facebook</SelectItem>
                          <SelectItem value="TikTok">TikTok</SelectItem>
                          <SelectItem value="Instagram">Instagram</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label>Service Name</Label>
                      <Input name="service_name" defaultValue={editingService?.service_name} required />
                    </div>
                    <div>
                      <Label>Price per Unit (KSH)</Label>
                      <Input 
                        name="price_per_unit" 
                        type="number" 
                        step="0.01" 
                        defaultValue={editingService?.price_per_unit}
                        required 
                      />
                    </div>
                    <div>
                      <Label>Min Quantity</Label>
                      <Input 
                        name="min_quantity" 
                        type="number" 
                        defaultValue={editingService?.min_quantity || 1}
                        required 
                      />
                    </div>
                    <div>
                      <Label>Max Quantity</Label>
                      <Input 
                        name="max_quantity" 
                        type="number" 
                        defaultValue={editingService?.max_quantity || 10000}
                        required 
                      />
                    </div>
                    <DialogFooter>
                      <Button type="submit" className="bg-gradient-primary" disabled={loading}>
                        {loading ? 'Saving...' : 'Save Service'}
                      </Button>
                    </DialogFooter>
                  </div>
                </form>
              </DialogContent>
            </Dialog>

            {services.map((service) => (
              <Card key={service.id} className="shadow-md">
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-lg flex items-center gap-2">
                        {service.category} - {service.service_name}
                        {!service.is_active && <Badge variant="secondary">Inactive</Badge>}
                      </CardTitle>
                      <CardDescription>
                        {formatAmount(service.price_per_unit)}/unit | Min: {service.min_quantity} | Max: {service.max_quantity}
                      </CardDescription>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          setEditingService(service);
                          setShowServiceDialog(true);
                        }}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button variant="destructive" size="sm">
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent className="bg-card">
                          <AlertDialogHeader>
                            <AlertDialogTitle>Delete Service</AlertDialogTitle>
                            <AlertDialogDescription>
                              Are you sure? This will affect existing orders.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction onClick={() => deleteService(service.id)}>
                              Delete
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </div>
                </CardHeader>
              </Card>
            ))}
          </TabsContent>

          <TabsContent value="notifications">
            <Card className="shadow-md">
              <CardHeader>
                <CardTitle>Send Notification</CardTitle>
                <CardDescription>Send notifications to all users or individual users</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={sendNotification} className="space-y-4">
                  <div>
                    <Label>Recipient</Label>
                    <Select name="recipient" defaultValue="all" required>
                      <SelectTrigger className="bg-card">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-card">
                        <SelectItem value="all">All Users</SelectItem>
                        {users.map(user => (
                          <SelectItem key={user.id} value={user.id}>
                            {user.full_name} ({user.email})
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>Title</Label>
                    <Input name="title" required />
                  </div>
                  <div>
                    <Label>Message</Label>
                    <Input name="message" required />
                  </div>
                  <Button type="submit" className="bg-gradient-primary" disabled={loading}>
                    {loading ? 'Sending...' : 'Send Notification'}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default Admin;