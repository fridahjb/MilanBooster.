import { useCurrency } from '@/contexts/CurrencyContext';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

export const CurrencySelector = () => {
  const { currencies, selectedCurrency, setSelectedCurrency } = useCurrency();

  return (
    <Select
      value={selectedCurrency?.code}
      onValueChange={(code) => {
        const currency = currencies.find(c => c.code === code);
        if (currency) setSelectedCurrency(currency);
      }}
    >
      <SelectTrigger className="w-32 bg-card">
        <SelectValue />
      </SelectTrigger>
      <SelectContent className="bg-card">
        {currencies.map((currency) => (
          <SelectItem key={currency.id} value={currency.code}>
            {currency.code} {currency.symbol}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
};