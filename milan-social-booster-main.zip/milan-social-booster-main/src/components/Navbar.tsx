import { Link } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { useCurrency } from '@/contexts/CurrencyContext';
import { Button } from '@/components/ui/button';
import { CurrencySelector } from '@/components/CurrencySelector';
import { Bell, Menu, Wallet, User } from 'lucide-react';
import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Sheet,
  SheetContent,
  SheetTrigger,
} from '@/components/ui/sheet';

export const Navbar = () => {
  const { user, userRole, signOut } = useAuth();
  const { formatAmount } = useCurrency();
  const [balance, setBalance] = useState(0);
  const [unreadCount, setUnreadCount] = useState(0);

  useEffect(() => {
    if (user) {
      fetchBalance();
      fetchUnreadNotifications();
    }
  }, [user]);

  const fetchBalance = async () => {
    if (!user) return;
    const { data } = await supabase
      .from('profiles')
      .select('balance')
      .eq('id', user.id)
      .single();
    
    if (data) setBalance(data.balance);
  };

  const fetchUnreadNotifications = async () => {
    if (!user) return;
    const { count } = await supabase
      .from('notifications')
      .select('*', { count: 'exact', head: true })
      .eq('user_id', user.id)
      .eq('is_read', false);
    
    if (count) setUnreadCount(count);
  };

  const NavLinks = () => (
    <>
      <Link to="/dashboard">
        <Button variant="ghost">Dashboard</Button>
      </Link>
      <Link to="/order">
        <Button variant="ghost">New Order</Button>
      </Link>
      <Link to="/orders">
        <Button variant="ghost">My Orders</Button>
      </Link>
      {userRole === 'admin' && (
        <Link to="/admin">
          <Button variant="ghost">Admin Panel</Button>
        </Link>
      )}
    </>
  );

  return (
    <nav className="sticky top-0 z-50 w-full border-b border-border bg-card/80 backdrop-blur-lg shadow-sm">
      <div className="container mx-auto px-4">
        <div className="flex h-16 items-center justify-between">
          <div className="flex items-center gap-8">
            <Link to="/" className="flex items-center gap-2">
              <div className="h-8 w-8 rounded-lg bg-gradient-primary" />
              <span className="text-xl font-bold">Milan Booster</span>
            </Link>
            
            <div className="hidden md:flex items-center gap-2">
              {user && <NavLinks />}
            </div>
          </div>

          <div className="flex items-center gap-4">
            {user && (
              <>
                <div className="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-lg bg-gradient-primary text-primary-foreground shadow-glow">
                  <Wallet className="h-4 w-4" />
                  <span className="font-semibold">{formatAmount(balance)}</span>
                </div>

                <CurrencySelector />

                <Link to="/notifications">
                  <Button variant="ghost" size="icon" className="relative">
                    <Bell className="h-5 w-5" />
                    {unreadCount > 0 && (
                      <span className="absolute -top-1 -right-1 h-5 w-5 rounded-full bg-destructive text-destructive-foreground text-xs flex items-center justify-center">
                        {unreadCount}
                      </span>
                    )}
                  </Button>
                </Link>

                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon">
                      <User className="h-5 w-5" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="bg-card">
                    <DropdownMenuItem asChild>
                      <Link to="/profile">Profile</Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={signOut}>
                      Sign Out
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>

                <Sheet>
                  <SheetTrigger asChild className="md:hidden">
                    <Button variant="ghost" size="icon">
                      <Menu className="h-5 w-5" />
                    </Button>
                  </SheetTrigger>
                  <SheetContent>
                    <div className="flex flex-col gap-4 mt-8">
                      <div className="flex items-center gap-2 px-3 py-2 rounded-lg bg-gradient-primary text-primary-foreground">
                        <Wallet className="h-4 w-4" />
                        <span className="font-semibold">{formatAmount(balance)}</span>
                      </div>
                      <NavLinks />
                    </div>
                  </SheetContent>
                </Sheet>
              </>
            )}
            {!user && (
              <Link to="/auth">
                <Button className="bg-gradient-primary">Sign In</Button>
              </Link>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
};