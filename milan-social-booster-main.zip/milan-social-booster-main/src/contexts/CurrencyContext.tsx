import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { supabase } from '@/integrations/supabase/client';

type Currency = {
  id: string;
  code: string;
  name: string;
  symbol: string;
  exchange_rate: number;
};

type CurrencyContextType = {
  currencies: Currency[];
  selectedCurrency: Currency | null;
  setSelectedCurrency: (currency: Currency) => void;
  convertAmount: (amount: number) => number;
  formatAmount: (amount: number) => string;
};

const CurrencyContext = createContext<CurrencyContextType | undefined>(undefined);

export const CurrencyProvider = ({ children }: { children: ReactNode }) => {
  const [currencies, setCurrencies] = useState<Currency[]>([]);
  const [selectedCurrency, setSelectedCurrency] = useState<Currency | null>(null);

  useEffect(() => {
    fetchCurrencies();
  }, []);

  const fetchCurrencies = async () => {
    const { data, error } = await supabase
      .from('currencies')
      .select('*')
      .eq('is_active', true)
      .order('code');

    if (error) {
      console.error('Error fetching currencies:', error);
      return;
    }

    setCurrencies(data || []);
    // Set KSH as default
    const ksh = data?.find(c => c.code === 'KSH');
    if (ksh) setSelectedCurrency(ksh);
  };

  const convertAmount = (amount: number) => {
    if (!selectedCurrency) return amount;
    return amount * selectedCurrency.exchange_rate;
  };

  const formatAmount = (amount: number) => {
    if (!selectedCurrency) return `KSH ${amount.toFixed(2)}`;
    const converted = convertAmount(amount);
    return `${selectedCurrency.symbol} ${converted.toFixed(2)}`;
  };

  return (
    <CurrencyContext.Provider 
      value={{ 
        currencies, 
        selectedCurrency, 
        setSelectedCurrency, 
        convertAmount, 
        formatAmount 
      }}
    >
      {children}
    </CurrencyContext.Provider>
  );
};

export const useCurrency = () => {
  const context = useContext(CurrencyContext);
  if (!context) {
    throw new Error('useCurrency must be used within CurrencyProvider');
  }
  return context;
};