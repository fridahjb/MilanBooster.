-- Add explicit policy to deny anonymous access to profiles table
CREATE POLICY "Deny anonymous access to profiles"
ON public.profiles
FOR SELECT
TO anon
USING (false);

-- Fix notifications policy to split user-specific and public notifications
-- First, drop the existing policy that allows NULL user_id
DROP POLICY IF EXISTS "Users can view their own notifications" ON public.notifications;

-- Create separate policies for user-specific and public notifications
CREATE POLICY "Users can view their own notifications"
ON public.notifications
FOR SELECT
TO authenticated
USING (auth.uid() = user_id);

CREATE POLICY "Users can view public notifications"
ON public.notifications
FOR SELECT
TO authenticated
USING (user_id IS NULL);

-- Add explicit denial for anonymous users on notifications
CREATE POLICY "Deny anonymous access to notifications"
ON public.notifications
FOR SELECT
TO anon
USING (false);