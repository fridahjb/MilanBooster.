-- Add explicit policy to deny anonymous access to orders table
CREATE POLICY "Deny anonymous access to orders"
ON public.orders
FOR SELECT
TO anon
USING (false);