-- Create a function to add admin role to a user
CREATE OR REPLACE FUNCTION public.make_user_admin(target_user_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Insert admin role if it doesn't exist
  INSERT INTO public.user_roles (3f371c67-14d5-4a22-81eb-3b63832c906e, admin)
  VALUES (target_user_id, 'admin'::app_role)
  ON CONFLICT (user_id, role) DO NOTHING;
END;
$$;

-- Grant execute permission to authenticated users (only admins should use this in practice)
GRANT EXECUTE ON FUNCTION public.make_user_admin(uuid) TO authenticated;